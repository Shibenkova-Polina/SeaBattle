package ru.game.seabattle.elements;

public enum ShootResult {
    MISS,
    INJURE,
    KILL
}
