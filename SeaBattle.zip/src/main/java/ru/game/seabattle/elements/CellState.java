package ru.game.seabattle.elements;

public enum CellState {
    SEA,
    MISS,
    SHIP,
    INJURE,
    KILL
}
